using UnityEngine;

[System.Serializable]
public struct PlayerStats
{
    public int powerValue;
    public int judgeValue;
    public int criticalValue;
}

[DefaultExecutionOrder(-10000)]
public class PlayerManager : MonoBehaviour
{
    #region �̱���
    static PlayerManager instance;
    public static PlayerManager Instance
    {
        get
        {
            if (instance == null && Time.timeScale != 0)
            {
                var obj = FindAnyObjectByType<PlayerManager>();
                if (obj != null)
                {
                    instance = obj;
                    print("�ø� ã�� ����");
                }
                else
                {
                    print("�ø� ����");
                    instance = Create();
                }
            }
            return instance;
        }
    }
    static PlayerManager Create()
    {
        Debug.LogWarning("PlayerManager ����");
        return Instantiate(Resources.Load<PlayerManager>("PlayerManager"));
    }
    #endregion
    [Header("�÷��̾� ����")]
    [SerializeField, ReadOnly] PlayerStatSO baseStats;
    [SerializeField, ReadOnly] BatItemSO currentBat;
    [SerializeField, ReadOnly] int currentBatLevel;

    [Header("�÷��̾� ����")]
    [SerializeField, ReadOnly] int maxValue = 60;
    [SerializeField, ReadOnly] PlayerStats playerstat;

    [Header("��ȭ")]
    [SerializeField, ReadOnly] int currency;//��ȭ
    [SerializeField, ReadOnly] int redistributionCost = 10000;     //��й� ���

    BatLevelData levelData;


    public int PowerValue { get { return playerstat.powerValue; } set { playerstat.powerValue = value; } }
    public int JudgeValue { get { return playerstat.judgeValue; } set { playerstat.judgeValue = value; } }
    public int CriticalValue { get { return playerstat.criticalValue; } set { playerstat.criticalValue = value; } }

    public int Currency => currency;

    public float CurrentPower => baseStats.BasePower + PowerValue + levelData.powerBonus;
    public float CurrentJudgeSight => baseStats.BaseJudgement + JudgeValue + levelData.judgementBonus;
    public float CurrentCritical => baseStats.BaseCriticalChance + CriticalValue + levelData.criticalBonus;

    void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(gameObject);
            return;
        }

        instance = this;
        DontDestroyOnLoad(gameObject);

        LoadData();
        SetBatLevel();
    }

    void SetBatLevel()
    {
        levelData = currentBat.GetBatData(currentBatLevel);
    }
    public void Reset()
    {
        PlayerPrefs.SetInt("Currency", 100000);
        PlayerPrefs.SetInt("PowerValue", 10);
        PlayerPrefs.SetInt("JudgeValue", 10);
        PlayerPrefs.SetInt("CriticalValue", 10);
        PlayerPrefs.SetInt("currentBatLevel", 0);
        PlayerPrefs.Save();
        LoadData();
        SetBatLevel();
        Initialization();

    }
    void LoadData()
    {
        currency = PlayerPrefs.GetInt("Currency", 100000);
        PowerValue = PlayerPrefs.GetInt("PowerValue", 10);
        JudgeValue = PlayerPrefs.GetInt("JudgeValue", 10);
        CriticalValue = PlayerPrefs.GetInt("CriticalValue", 10);
        currentBatLevel = PlayerPrefs.GetInt("currentBatLevel", 0);
    }
    void SaveData()
    {
        PlayerPrefs.SetInt("Currency", currency);
        PlayerPrefs.SetInt("PowerValue", PowerValue);
        PlayerPrefs.SetInt("JudgeValue", JudgeValue);
        PlayerPrefs.SetInt("CriticalValue", CriticalValue);
        PlayerPrefs.SetInt("currentBatLevel", currentBatLevel);
        PlayerPrefs.Save();
    }

    public void Initialization()
    {
        EventManager.Instance.PublishCurrencyChanged(currency);
        EventManager.Instance.PublishPlayerStatsChanged(PowerValue, JudgeValue, CriticalValue);
        EventManager.Instance.PublishBatUpgraded(currentBat, currentBatLevel);
    }


    public void SpendCurrency(int cost)
    {
        if (cost > currency) { print("�ܾ� ����"); return; }
        currency -= cost;
        EventManager.Instance.PublishCurrencyChanged(currency);
    }
    public bool HasEnoughCurrency(int cost)
    {
        return currency >= cost;
    }
    public void AddCurrency(int cost)
    {
        if (cost <= 0) { print("�߰��� ���� ���µ���"); return; }
        currency += cost;
        EventManager.Instance.PublishCurrencyChanged(currency);
    }
    //��й�
    public void Redistribution()
    {
        //if (!HasEnoughCurrency(redistributionCost)) return;
        SpendCurrency(redistributionCost);
        int x, y;
        x = Random.Range(0, maxValue + 1);
        y = Random.Range(0, maxValue + 1);

        if (x > y)
        {
            (x, y) = (y, x);
        }
        int a = x;
        int b = y - x;
        int c = maxValue - y;
        int[] ranArr = { a, b, c };
        for (int i = 0; i < ranArr.Length; i++)
        {
            int randIndex = Random.Range(i, ranArr.Length);
            (ranArr[i], ranArr[randIndex]) = (ranArr[randIndex], ranArr[i]);
        }
        PowerValue = ranArr[0];
        JudgeValue = ranArr[1];
        CriticalValue = ranArr[2];
        EventManager.Instance.PublishPlayerStatsChanged(PowerValue, JudgeValue, CriticalValue);
    }
    public void Upgrade()
    {
        //if (!HasEnoughCurrency(levelData.upgradeCost)) return;
        SpendCurrency(levelData.upgradeCost);

        if (currentBatLevel < currentBat.maxLevel)
        {
            if (Random.value * 100 <= levelData.upgradeChance)
            {
                currentBatLevel++;
                SetBatLevel();
                EventManager.Instance.PublishBatUpgraded(currentBat, currentBatLevel);
            }
        }
        else return;
    }
    public int GetUpgradeCost()
    {
        return levelData.upgradeCost;
    }

    public int GetredistributionCostCost()
    {
        return redistributionCost;
    }
    void OnApplicationQuit()
    {
        SaveData();
    }

    void OnApplicationPause(bool pause)
    {
        if (pause)
        {
            SaveData();
        }
    }
}