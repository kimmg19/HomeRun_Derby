using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum EHitTiming
{
    Fast,
    Perfect,
    Slow,
    Miss
}