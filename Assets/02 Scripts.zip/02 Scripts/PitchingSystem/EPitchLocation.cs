using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum EPitchLocation
{
    STRIKE,
    BALL
}
