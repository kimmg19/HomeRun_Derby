//����
public enum EPitchType
{
    FASTBALL,
    CURVE,
    SLIDER,
    CHANGEUP    
}
